package render

import (
	"html/template"

	"github.com/mlogclub/simple"
)

func BuildTopic() *model.TopicResponse {
	if topic == nil {
		return nil
	}

	rsp := &model.TopicResponse{}

	mr := simple.NewMd(simple.MdWithTOC()).Run(topic.Content)
	rsp.Content = template.HTML(BuildHtmlContent(mr.ContentHtml))
	rsp.Toc = template.HTML(mr.TocHtml)

	return rsp
}
