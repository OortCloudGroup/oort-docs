package models

var MsgFlags = map[int]string{
	SUCCESS: "成功",
	ERROR:   "未知消息",

	ADD_OBJ:      "新增",
	EDIT_OBJ:     "修改",
	DELETE_OBJ:   "删除",
	QUERY_OBJ:    "查询",
	PUBLISH_OBJ:  "发布",
	OFFLINE_OBJ:  "下线",
	AGREE_OBJ:    "同意",
	DISAGREE_OBJ: "不同意",

	CLASSIFY_OBJ: "分类",
	SUPPLIER_OBJ: "供应商",
	APP_OBJ:      "应用",
	SERVICE_OBJ:  "服务",
	AUTH_OBJ:     "授权",
	AUDIT_OBJ:    "审核",
}
