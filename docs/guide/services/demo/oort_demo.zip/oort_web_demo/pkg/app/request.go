package app

import (
	"fmt"

	"github.com/EDDYCJY/go-gin-example/pkg/logging"
	"github.com/astaxie/beego/validation"
)

// MarkErrors logs error logs
func MarkErrors(errors []*validation.Error) {
	for _, err := range errors {
		logging.Info(err.Key, err.Message)
		fmt.Println(err.Key, err.Message)
	}

	return
}
