package gredis

import (
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/EDDYCJY/go-gin-example/pkg/setting"
	cluster "github.com/go-redis/redis"
	"github.com/gomodule/redigo/redis"
)

var RedisConn *redis.Pool
var RedisCluster *cluster.ClusterClient

func InitRedis() {
	if setting.RedisSetting.Cluster == 1 {
		fmt.Println("使用redis集群方式")
		ClusterSetup()
	} else {
		fmt.Println("使用redis单节点方式")
		Setup()
	}

	Redis_Test("redis")
}

// Setup Initialize the Redis instance
func Setup() error {
	RedisConn = &redis.Pool{
		MaxIdle:     setting.RedisSetting.MaxIdle,
		MaxActive:   setting.RedisSetting.MaxActive,
		IdleTimeout: setting.RedisSetting.IdleTimeout,
		Dial: func() (redis.Conn, error) {
			fmt.Println("--->redis host :", setting.RedisSetting.Host, setting.RedisSetting.DB)
			//c, err := redis.Dial("tcp", setting.RedisSetting.Host)
			c, err := redis.Dial("tcp", setting.RedisSetting.Host, redis.DialDatabase(setting.RedisSetting.DB), redis.DialPassword(setting.RedisSetting.Password))
			if err != nil {
				fmt.Println("redis connect fail")
				return nil, err
			}
			// if setting.RedisSetting.Password != "" {
			// 	if _, err := c.Do("AUTH", setting.RedisSetting.Password); err != nil {
			// 		c.Close()
			// 		return nil, err
			// 	}
			// }
			//c.Do("SELECT", 2) //db1
			return c, err
		},
		TestOnBorrow: func(c redis.Conn, t time.Time) error {
			_, err := c.Do("PING")
			return err
		},
	}
	return nil
}

//GetRDCluster 集群redis
func ClusterSetup() {
	addr := strings.Split(setting.RedisSetting.Host, ",")
	fmt.Println("addr :", addr)
	RedisCluster = cluster.NewClusterClient(&cluster.ClusterOptions{
		Addrs:    addr,                          //set redis cluster url
		Password: setting.RedisSetting.Password, //set password
	})
	go redisKeepAliveCluster(RedisCluster)

}

//redisKeepAliveCluster REDIS 保连
func redisKeepAliveCluster(client *cluster.ClusterClient) {
	for {
		client.Ping().Result()
		time.Sleep(60 * time.Second)
	}
}

//return models.DB.RDC.Set("LockSMS:"+Mobile, str, time.Minute*5*viper.GetDuration("sms.time")).Err()

// Set a string
func ClusterSetString(key string, value []byte, timeout int) error {
	err := RedisCluster.Set(key, value, time.Duration(timeout)*time.Second).Err()
	if err != nil {
		return err
	}

	return nil
}

// Exists check a key
func ClusterExists(key string) bool {
	if RedisCluster == nil {
		return false
	}
	res, err := RedisCluster.Exists(key).Result()
	if err != nil {
		fmt.Println("执行redis失败:", err)
		return false
	}
	if res != 1 {
		//fmt.Println("redis key 不存在:")
		return false
	}
	return true
}

// Exists check a key
func ClusterHExists(key string, filed string) bool {
	res, err := RedisCluster.HExists(key, filed).Result()
	if err != nil {
		fmt.Println("执行redis失败:", err)
		return false
	}

	return res
}

// del a key
func ClusterDel(key string) error {
	err := RedisCluster.Del(key).Err()
	if err != nil {
		return err
	}
	return nil
}

//hget get a key
func ClusterGet(key string, field string) (string, error) {

	res, err := RedisCluster.Get(key).Result()
	if err != nil {
		return "", err
	}

	return res, nil
}

//入队,到底部
func ClusterRpush(key string, field string) error {

	_, err := RedisCluster.Do("rpush", key, field).Result()
	if err != nil {
		return err
	}

	return nil
}

//出队,从顶部
func ClusterLpop(key string) (string, error) {

	res, err := RedisCluster.Do("lpop", key).Result()
	if err != nil {
		return "", err
	}

	return res.(string), nil
}

func ClusterHset(key string, filed string, value string) error {

	_, err := RedisCluster.Do("HSet", key, filed, value).Result()
	if err != nil {
		return err
	}

	return nil
}

func ClusterHget(key string, filed string) (string, error) {

	res, err := RedisCluster.Do("HGet", key, filed).Result()
	if err != nil {
		return "", err
	}

	return res.(string), nil
}

//以下是非集群操作方式
// Set a key/value
func Set(key string, data interface{}, time int) error {
	conn := RedisConn.Get()
	defer conn.Close()

	value, err := json.Marshal(data)
	if err != nil {
		return err
	}

	_, err = conn.Do("SET", key, value)
	if err != nil {
		return err
	}
	if time != 0 {
		_, err = conn.Do("EXPIRE", key, time)
		if err != nil {
			return err
		}
	}

	return nil
}

// Set a string
func SetString(key string, value string, time int) error {
	conn := RedisConn.Get()
	defer conn.Close()

	_, err := conn.Do("SET", key, value)
	if err != nil {
		return err
	}
	if time != 0 {
		_, err = conn.Do("EXPIRE", key, time)
		if err != nil {
			return err
		}
	}
	return nil
}

//hget set a key
func Hset(key string, field string, value string, time int) error {
	conn := RedisConn.Get()
	defer conn.Close()

	_, err := conn.Do("hset", key, field, value)
	if err != nil {
		fmt.Println("haset failed", err.Error())
		return err
	}

	if time != 0 {
		_, err = conn.Do("EXPIRE", key, time)
		if err != nil {
			return err
		}
	}
	return nil
}

//hget get a key
func Hget(key string, field string) ([]byte, error) {
	conn := RedisConn.Get()
	defer conn.Close()

	reply, err := redis.Bytes(conn.Do("hget", key, field))
	if err != nil {
		return nil, err
	}

	return reply, nil
}

//hget get all key/value
func Hgetall(key string) (map[string]string, error) {
	conn := RedisConn.Get()
	defer conn.Close()

	reply, err := redis.Values(conn.Do("hgetall", key))
	if err != nil {
		return nil, err
	}
	list := make(map[string]string)
	index := ""
	for _, phone := range reply {
		str := string(phone.([]byte))
		if index == "" {
			index = str
		} else {
			list[index] = str
			index = ""
		}
	}

	return list, nil
}

//ClusterHgetall Hgetall keys
func ClusterHgetall(key string) (map[string]string, error) {
	res, err := RedisCluster.HGetAll(key).Result()
	if err != nil {
		fmt.Println("执行redis失败:", err)
		return nil, err
	}
	return res, nil
}

//hdel del a key field
func Hdel(key string, field string) (bool, error) {
	conn := RedisConn.Get()
	defer conn.Close()

	return redis.Bool(conn.Do("HDEL", key, field))
}

//ClusterHdel Hdel key field
func ClusterHdel(key string, field string) (bool, error) {
	res, err := RedisCluster.HDel(key, field).Result()
	if err != nil {
		fmt.Println("执行redis失败:", err)
		return false, err
	}
	fmt.Println(res)
	return res == 1, nil
}

// Exists check a key
func Exists(key string) bool {
	if RedisConn == nil {
		return false
	}
	conn := RedisConn.Get()
	defer conn.Close()

	exists, err := redis.Bool(conn.Do("EXISTS", key))
	if err != nil {
		return false
	}

	return exists
}

func HExists(key string, filed string) bool {
	conn := RedisConn.Get()
	defer conn.Close()

	exists, err := redis.Bool(conn.Do("HEXISTS", key, filed))
	if err != nil {
		return false
	}

	return exists

}

func LLen(key string) int {
	conn := RedisConn.Get()
	defer conn.Close()

	length, err := redis.Int(conn.Do("LLEN", key))
	if err != nil {
		return 0
	}

	return length
}

// Get get a key
func Get(key string) ([]byte, error) {
	conn := RedisConn.Get()
	defer conn.Close()

	reply, err := redis.Bytes(conn.Do("GET", key))
	if err != nil {
		return nil, err
	}

	return reply, nil
}

// Delete delete a kye
func Delete(key string) (bool, error) {
	conn := RedisConn.Get()
	defer conn.Close()

	return redis.Bool(conn.Do("DEL", key))
}

// LikeDeletes batch delete
func LikeDeletes(key string) error {
	conn := RedisConn.Get()
	defer conn.Close()

	keys, err := redis.Strings(conn.Do("KEYS", "*"+key+"*"))
	if err != nil {
		return err
	}

	for _, key := range keys {
		_, err = Delete(key)
		if err != nil {
			return err
		}
	}

	return nil
}

//-----------------list---------------------------------------------------------->>>>>
func Lpush(key string, value string) error {
	conn := RedisConn.Get()
	defer conn.Close()

	_, err := conn.Do("lpush", key, value)
	if err != nil {
		fmt.Println("redis lpush failed:", err)
		return err
	}
	return nil
}

func Lpop(key string) (string, error) {
	conn := RedisConn.Get()
	defer conn.Close()

	res, err := redis.String(conn.Do("lpop", key))
	if err != nil {
		//fmt.Println("redis lpop failed:", err)
		return "", err
	}

	return res, nil
}

func Lrange(key string, start int, end int) ([]interface{}, error) {
	conn := RedisConn.Get()
	defer conn.Close()

	reply, err := redis.Values(conn.Do("lrange", key, start, end))
	if err != nil {
		return nil, err
	}

	return reply, nil
	/*
		for _, v := range reply {
			fmt.Println(string(v.([]byte)))
		}
	*/
}

func Rpush(key string, value string) error {
	conn := RedisConn.Get()
	defer conn.Close()

	_, err := conn.Do("rpush", key, value)
	if err != nil {
		fmt.Println("redis lpush failed:", err)
		return err
	}
	return nil
}

//<<<<-----------------list----------------------------------------------------------

func ZAdd(key string, score int, value string) error {
	conn := RedisConn.Get()
	defer conn.Close()

	_, err := conn.Do("ZADD", key, "INCR", score, value)
	if err != nil {
		fmt.Println("ZADD failed", err.Error())
		return err
	}
	return nil
}

//移除集合中的某一个或者多个成员
func ZDel(key string, value string) error {
	conn := RedisConn.Get()
	defer conn.Close()

	_, err := conn.Do("ZREM", key, value)
	if err != nil {
		return err
	}
	return nil
}

// 读取指定zset
func ZRang(key string, from int, to int) ([]interface{}, error) { //不要使用map返回，map是无序的
	conn := RedisConn.Get()
	defer conn.Close()
	//user_map, err := redis.Values(conn.Do("ZRANGE", key, from, to, "withscores"))
	//user_map, err := redis.Values(conn.Do("zrevrange", key, from, to, "withscores")) //按照插入后先返回，最新插入的先返回
	user_map, err := redis.Values(conn.Do("zrevrange", key, from, to)) //按照插入后先返回，最新插入的先返回
	if err != nil {
		fmt.Println("redis get failed:", err)
		return nil, err
	}
	/*
		for user := range user_map {
			fmt.Printf("user name: %v %v\n", user, user_map[user])
		}
	*/
	return user_map, nil
}

func ZExec(cmd string, key string, from int, to int) ([]interface{}, error) {
	conn := RedisConn.Get()
	defer conn.Close()

	user_map, err := redis.Values(conn.Do(cmd, key, from, to))
	if err != nil {
		fmt.Println(cmd, " failed:", err)
		return nil, err
	}
	return user_map, nil
}

//------------------------------set-----------------------------------------------
func SAdd(key string, value string) error {
	conn := RedisConn.Get()
	defer conn.Close()

	_, err := conn.Do("SADD", key, value)
	if err != nil {
		fmt.Println("redis mset error:", err)
		return err
	}

	return nil
}

func SRem(key string, value string) error {
	conn := RedisConn.Get()
	defer conn.Close()

	_, err := conn.Do("srem", key, value)
	if err != nil {
		fmt.Println("redis mset error:", err)
		return err
	}

	return nil
}

func Smembers(key string) ([]interface{}, error) {
	conn := RedisConn.Get()
	defer conn.Close()

	//获取test_set集合中的所有数据，并循环遍历打印
	list_set, err := redis.Values(conn.Do("SMEMBERS", key))
	if err != nil {
		fmt.Println("Smembers err:", err)
		return nil, err
	}
	/*
		for _, v := range list_set {
			if str, ok := v.([]uint8); ok {
				fmt.Println("test_set:", string(str))
			}
		}
	*/
	return list_set, nil
}

//------------------------------set-----------------------------------------------

func Redis_Set(key string, value string, timeout int) error {
	if setting.RedisSetting.Cluster == 1 {
		err := RedisCluster.Set(key, value, time.Duration(timeout)*time.Second).Err()
		if err != nil {
			return err
		}
	} else {
		err := SetString(key, value, timeout)
		if err != nil {
			return err
		}
	}

	return nil
}

func Redis_Get(key string) (string, error) {

	if setting.RedisSetting.Cluster == 1 {
		res, err := RedisCluster.Get(key).Result()
		if err != nil {
			return "", err
		}

		return res, nil
	} else {
		conn := RedisConn.Get()
		defer conn.Close()

		reply, err := redis.Bytes(conn.Do("GET", key))
		if err != nil {
			return "", err
		}

		return string(reply), nil
	}
}

func Redis_HSet(key string, filed string, value string) error {
	if setting.RedisSetting.Cluster == 1 {
		err := ClusterHset(key, filed, value)
		if err != nil {
			return err
		}
	} else {
		err := Hset(key, filed, value, 0)
		if err != nil {
			return err
		}
	}

	return nil
}

func Redis_Hget(key string, filed string) (string, error) {
	if setting.RedisSetting.Cluster == 1 {
		res, err := ClusterHget(key, filed)
		if err != nil {
			return "", err
		}

		return res, nil
	} else {
		res, err := Hget(key, filed)
		if err != nil {
			return "", err
		}

		return string(res), nil
	}

}

//Redis_HDel Redis_HDel
func Redis_HDel(key string, filed string) (bool, error) {

	if setting.RedisSetting.Cluster == 1 {
		res, err := ClusterHdel(key, filed)
		if err != nil {
			return false, err
		}

		return res, nil
	} else {
		res, err := Hdel(key, filed)
		if err != nil {
			return false, err
		}

		return res, nil
	}
}

//Redis_Hgetall Redis_Hgetall
func Redis_Hgetall(key string) (map[string]string, error) {
	if setting.RedisSetting.Cluster == 1 {
		res, err := ClusterHgetall(key)
		if err != nil {
			return nil, err
		}

		return res, nil
	} else {
		res, err := Hgetall(key)
		if err != nil {
			return nil, err
		}

		return res, nil
	}

}

func Redis_Exist(key string) bool {
	if setting.RedisSetting.Cluster == 1 {
		if ClusterExists(key) {
			return true
		}
	} else {
		if Exists(key) {
			return true
		}
	}
	return false
}

func Redis_HExist(key string, filed string) bool {
	if setting.RedisSetting.Cluster == 1 {
		if ClusterHExists(key, filed) {
			return true
		}
	} else {
		if HExists(key, filed) {
			return true
		}
	}
	return false
}

func Redis_Del(key string) error {
	if setting.RedisSetting.Cluster == 1 {
		err := ClusterDel(key)
		if err != nil {
			return err
		}
	} else {
		_, err := Delete(key)
		if err != nil {
			return err
		}

	}
	return nil
}

//入队，到底部
func Redis_Rpush(queue string, value string) error {
	if setting.RedisSetting.Cluster == 1 {
		err := ClusterRpush(queue, value)
		if err != nil {
			return err
		}
	} else {
		err := Lpush(queue, value)
		if err != nil {
			return err
		}

	}
	return nil
}

//出队，从顶部
func Redis_Lpop(queue string) (string, error) {
	if setting.RedisSetting.Cluster == 1 {
		res, err := ClusterLpop(queue)
		if err != nil {
			return "", err
		}
		return res, nil
	} else {
		res, err := Lpop(queue)
		if err != nil {
			return "", err
		}
		return res, nil
	}
}

// Incr num
func IncrNum(key string) error {
	conn := RedisConn.Get()
	defer conn.Close()

	_, err := conn.Do("INCR", key)
	if err != nil {
		return err
	}
	return nil
}

func Redis_Incr(key string) error {
	if setting.RedisSetting.Cluster == 1 {
		err := RedisCluster.Incr(key).Err()
		if err != nil {
			return err
		}
	} else {
		err := IncrNum(key)
		if err != nil {
			return err
		}
	}

	return nil
}

//redis测试接口
func Redis_Test(queue string) error {
	key := "RedisTestKey"
	value := "RedisTestValue"

	Redis_Set(key, value, 10)
	data, err := Redis_Get(key)
	if err != nil {
		fmt.Println("Redis_Test err :", err)
		return err
	}

	if data == value {
		fmt.Println("Redis Test Ok")
	} else {
		fmt.Println("!!!!Redis Test Faild")
	}

	key_incr := "IncrNumtest"
	Redis_Set(key_incr, "20", 100)
	Redis_Incr(key_incr)
	fmt.Println("Redis set 20")
	indata, err := Redis_Get(key_incr)
	if err != nil {
		fmt.Println("Redis_Test err :", err)
		return err
	}
	fmt.Println("IncrNum:", indata)
	return nil
}
