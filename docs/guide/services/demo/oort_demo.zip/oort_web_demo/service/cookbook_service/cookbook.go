package cookbook_service

import (
	"github.com/EDDYCJY/go-gin-example/models"
)

type CommonParamsList struct {
	ID          int
	Uid         string
	Uuid        string
	AccessToken string
	PageNum     int
	PageSize    int
	StartTime   int
	EndTime     int
	IP          string
	Name        string
	Item        int
	Status      int

	Type         int
	Title        string
	Repeat       int
	AheadTime    int
	Teammate     string
	Remark       string
	Place        string
	Encrypted    int
	Organizer    string
	Conventioner string
	Executor     string
	Deadline     int
	PicUrl       string
	AccessoryUrl string
	Carboner     string
	Content      string
}

func (t *CommonParamsList) GetList() ([]models.Oort_cookbook, int, error) {
	return models.GetCookBookList(t.Content, t.Uuid, t.PageNum, t.PageSize, t.StartTime, t.EndTime, t.AccessToken)
}

// 判断uid是否存在
func (t *CommonParamsList) ExistByUid() (bool, error) {
	return models.ExistCookBookByUid(t.Uid)
}

func (t *CommonParamsList) Add() error {
	maps := map[string]interface{}{
		"title":   t.Title,
		"pic_url": t.PicUrl,
		"uuid":    t.Uuid,
	}

	if err := models.AddCookBook(maps, t.Uuid, t.AccessToken); err != nil {
		return err
	}

	return nil
}

func (t *CommonParamsList) Edit() error {
	maps := map[string]interface{}{
		"title":   t.Title,
		"pic_url": t.PicUrl,
	}

	if err := models.EditCookBook(maps, t.Uid, t.Uuid, t.AccessToken); err != nil {
		return err
	}

	return nil
}

func (t *CommonParamsList) Delete() error {
	return models.DeleteCookBook(t.Uid, t.Uuid, t.AccessToken)
}
func (t *CommonParamsList) Detail() (models.Oort_cookbook, error) {
	return models.DetailCookBook(t.Uid, t.Uuid, t.AccessToken)
}
