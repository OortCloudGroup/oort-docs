package auth_service

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"encoding/pem"
	"errors"
	"fmt"
	"os"

	"github.com/EDDYCJY/go-gin-example/models"
)

type Auth struct {
	Username string
	Password string
	Usertype int
}

func (a *Auth) Check() (bool, error) {
	return models.CheckAuth(a.Username, a.Password)
}

var privateKey = []byte(`  
-----BEGIN RSA PRIVATE KEY-----
MIICXQIBAAKBgQDux9+NUiibNyROj+EDAZPGtBRB/kMHRKqS2E7bvBdWpnrSwrTI
WDpCG3tkN1bV5aGNef6xcolgRZ0YNXqTxsxFj8uhZ5UTeDrzj+Qwy24loAcdJ7gh
Ycfcu3UbAhu7pNDFjCt/ILVwZ0o9qafaxQpaoE36PwZGQ0rfadU5YpZ9VwIDAQAB
AoGATJ8qp0ij6xrItcUJqVNKPkru7TZP//cS3Ug4Fd7HhnCpnRQJuvhEyY3UDJaN
cNnc+28YQYzFdHUiMfCHQwBZ76G5QFCc5lNKvPbVY4xV7wf7MbB80Pn9FPPwJlus
8e7LqFyI9HvIWU8jSgQQB76Mtg/r8OnpUsmsnuixdqnfEMECQQDxGeAddQAGLtro
Va/LvyddtDEsb5XZ5tI6p9o6ezoB3fJw7Zwz6Ive5leYmAKu4+1j0zgT50mjp+ie
JyigismxAkEA/YlKjg+IkpXLji8DeScmNlGJv6dIU1bdc0a2ZfVoAM7Z68ZoSMte
tUb8We3upftTl47631pVkoVsz1PMNQ9xhwJBANfZc5TLt57RefhBJmbBlwvEE7YV
nFH93T7YIX7z7YXYX4IMqCisy/RdwhSCGvzaYCBb7DudeIcE/zQAGNZKCrECQDwS
U3/lXk6c/2Xo7cG+7Obh2ul2EUTtx/qQPpdZ1hKa8DdVA1B8HyyEbTZBkdHyApRe
ZEKXfL8Crg1RpYjM5/ECQQDRpce0/kPx+vnQFakhihW/8ayfdMCml7nZM3gnFo3i
5pgSXhClvm0R8/OfaQXzqmCBEGf/WYNnb7eiWAMfVQwT
-----END RSA PRIVATE KEY-----
`)

var publicKey = []byte(`  
-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDux9+NUiibNyROj+EDAZPGtBRB
/kMHRKqS2E7bvBdWpnrSwrTIWDpCG3tkN1bV5aGNef6xcolgRZ0YNXqTxsxFj8uh
Z5UTeDrzj+Qwy24loAcdJ7ghYcfcu3UbAhu7pNDFjCt/ILVwZ0o9qafaxQpaoE36
PwZGQ0rfadU5YpZ9VwIDAQAB
-----END PUBLIC KEY-----
`)

func rsa_test_main() {
	//rsa 密钥文件产生
	GenRsaKey(1024)

	var data []byte
	var err error

	data, err = RsaEncrypt([]byte("polaris@studygolang.com"))
	if err != nil {
		panic(err)
	}
	fmt.Println("rsa encrypt base64:" + base64.StdEncoding.EncodeToString(data))

	origData, err := RsaDecrypt(data)
	if err != nil {
		panic(err)
	}
	fmt.Println(string(origData))
}

//RSA公钥私钥产生
func GenRsaKey(bits int) error {
	// 生成私钥文件
	privateKey, err := rsa.GenerateKey(rand.Reader, bits)
	if err != nil {
		return err
	}
	derStream := x509.MarshalPKCS1PrivateKey(privateKey)
	block := &pem.Block{
		Type:  "RSA PRIVATE KEY",
		Bytes: derStream,
	}
	file, err := os.Create("private.pem")
	if err != nil {
		return err
	}
	err = pem.Encode(file, block)
	if err != nil {
		return err
	}
	// 生成公钥文件
	publicKey := &privateKey.PublicKey
	derPkix, err := x509.MarshalPKIXPublicKey(publicKey)
	if err != nil {
		return err
	}
	block = &pem.Block{
		Type:  "PUBLIC KEY",
		Bytes: derPkix,
	}
	file, err = os.Create("public.pem")
	if err != nil {
		return err
	}
	err = pem.Encode(file, block)
	if err != nil {
		return err
	}
	return nil
}

// 加密
func RsaEncrypt(origData []byte) ([]byte, error) {
	block, _ := pem.Decode(publicKey)
	if block == nil {
		return nil, errors.New("public key error")
	}
	pubInterface, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		return nil, err
	}
	pub := pubInterface.(*rsa.PublicKey)
	return rsa.EncryptPKCS1v15(rand.Reader, pub, origData)
}

// 解密
func RsaDecrypt(ciphertext []byte) ([]byte, error) {
	block, _ := pem.Decode(privateKey)
	if block == nil {
		return nil, errors.New("private key error!")
	}
	priv, err := x509.ParsePKCS1PrivateKey(block.Bytes)
	if err != nil {
		return nil, err
	}
	return rsa.DecryptPKCS1v15(rand.Reader, priv, ciphertext)
}

func GetRsaPublicKey() (string, error) {
	return string(publicKey), nil
}
