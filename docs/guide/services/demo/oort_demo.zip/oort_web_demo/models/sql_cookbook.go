package models

//统一用户对接
//fastdfs对接

//每日食谱表
type Oort_cookbook struct {
	Model

	Uid     string `json:"uid" gorm:"primary_key;size:100;index:uid;"` //uid
	Uuid    string `json:"uuid" gorm:"column:uuid;not null"`           //创建人uuid
	Type    int    `json:"type" gorm:"default:0"`                      //类型
	Title   string `json:"title"`                                      //标题
	Content string `json:"content" gorm:"size:2048"`                   //内容
	PicUrl  string `json:"pic_url" gorm:"size:8192"`                   //图片url地址集
	Status  int    `json:"status" gorm:"default:0"`                    //状态
	Remark  string `json:"remark"`                                     //备注
	Day     string `json:"day" gorm:"size:100;index:day_key;"`         //日期(2006-01-01)
}
