package v1

import (
	"fmt"

	"net/http"

	"github.com/gin-gonic/gin"

	"github.com/EDDYCJY/go-gin-example/pkg/app"
	"github.com/EDDYCJY/go-gin-example/pkg/e"

	"github.com/EDDYCJY/go-gin-example/service/cookbook_service"
)

type CookBookListBody struct {
	AccessToken string `json:"accessToken" binding:"required" example:"token"`
	Uuid        string `json:"uuid" binding:"required" example:"登录者的uuid"`
	Content     string `json:"content" example:"搜索内容"`
	PageNum     int    `json:"pageNum"  example:"1"`  //页数
	PageSize    int    `json:"pageSize" example:"10"` //行数
	StartTime   int    `json:"startTime"`             //开始时间
	EndTime     int    `json:"endTime"`               //结束时间

}

// @Summary 每日食谱列表
// @Produce  json
// @Param target body v1.CookBookListBody true "每日食谱列表"
// @Success 200 {object} models.RespList
// @Failure 500 {object} app.Response
// @Router /v1/list [post]
// @Tags cookbook
func CookBookList(c *gin.Context) {
	var (
		appG = app.Gin{C: c}
		body CookBookListBody
	)

	httpCode, errCode, err := app.BindAndJsonCheck(c, &body)
	if errCode != e.SUCCESS {
		appG.Response(httpCode, errCode, err.Error())
		return
	}

	page := 1
	line := 10 //10
	if body.PageNum != 0 {
		page = body.PageNum
	}
	if body.PageSize != 0 {
		line = body.PageSize
	}

	fmt.Println(body.PageNum, body.PageSize)

	myService := cookbook_service.CommonParamsList{
		AccessToken: body.AccessToken,
		Uuid:        body.Uuid,
		Content:     body.Content,
		PageNum:     page,
		PageSize:    line,
		StartTime:   body.StartTime,
		EndTime:     body.EndTime,
	}

	rs, count, err := myService.GetList()
	if err != nil {
		fmt.Println(err)
		appG.Response(e.SUCCESS, e.ERROR_GET_SCHEDULE_FAIL, err)
		return
	}

	appG.Response(http.StatusOK, e.SUCCESS, map[string]interface{}{
		"lists": rs,
		"count": count,
	})
}

type AddCookBookBody struct {
	AccessToken string `json:"accessToken" binding:"required" example:"token"`
	Uuid        string `json:"uuid" binding:"required"`    //创建人uuid
	Title       string `json:"title" binding:"required"`   //标题
	PicUrl      string `json:"pic_url" binding:"required"` //图片url地址集
}

// @Summary 新增每日食谱
// @Produce  json
// @Param target body v1.AddCookBookBody true "新增每日食谱"
// @Success 200 {object} app.Response
// @Failure 500 {object} app.Response
// @Router /v1/add [post]
// @Tags cookbook
func AddCookBook(c *gin.Context) {
	var (
		appG = app.Gin{C: c}
		body AddCookBookBody
	)

	httpCode, errCode, err := app.BindAndJsonCheck(c, &body)
	if errCode != e.SUCCESS {
		appG.Response(httpCode, errCode, err.Error())
		return
	}

	myService := cookbook_service.CommonParamsList{
		AccessToken: body.AccessToken,
		Uuid:        body.Uuid,
		Title:       body.Title,
		PicUrl:      body.PicUrl,
	}

	err = myService.Add()
	if err != nil {
		fmt.Println(err)
		appG.Response(e.SUCCESS, e.ERROR_GET_SCHEDULE_FAIL, err)
		return
	}

	appG.Response(http.StatusOK, e.SUCCESS, nil)
}

type EditCookBookBody struct {
	AccessToken string `json:"accessToken" binding:"required" example:"token"`
	Uuid        string `json:"uuid" binding:"required"`    //创建人uuid
	Title       string `json:"title" binding:"required"`   //标题
	PicUrl      string `json:"pic_url" binding:"required"` //图片url地址集
	Uid         string `json:"uid" binding:"required"`     //uid
}

// @Summary 编辑每日食谱
// @Produce  json
// @Param target body v1.EditCookBookBody true "编辑每日食谱"
// @Success 200 {object} app.Response
// @Failure 500 {object} app.Response
// @Router /v1/edit [post]
// @Tags cookbook
func EditCookBook(c *gin.Context) {
	var (
		appG = app.Gin{C: c}
		body EditCookBookBody
	)

	httpCode, errCode, err := app.BindAndJsonCheck(c, &body)
	if errCode != e.SUCCESS {
		appG.Response(httpCode, errCode, err.Error())
		return
	}

	myService := cookbook_service.CommonParamsList{
		AccessToken: body.AccessToken,
		Uuid:        body.Uuid,
		Title:       body.Title,
		PicUrl:      body.PicUrl,
		Uid:         body.Uid,
	}

	exists, err := myService.ExistByUid()
	if err != nil {
		appG.Response(e.SUCCESS, e.ERROR_NOT_EXIST_SCHEDULE, nil)
		return
	}

	if !exists {
		appG.Response(http.StatusOK, e.ERROR_NOT_EXIST_SCHEDULE, nil)
		return
	}

	err = myService.Edit()
	if err != nil {
		fmt.Println(err)
		appG.Response(e.SUCCESS, e.ERROR_GET_SCHEDULE_FAIL, err)
		return
	}

	appG.Response(http.StatusOK, e.SUCCESS, nil)
}

type DeleteCookBookBody struct {
	AccessToken string `json:"accessToken" binding:"required" example:"token"`
	Uuid        string `json:"uuid" binding:"required"` //创建人uuid
	Uid         string `json:"uid" binding:"required"`  //uid
}

// @Summary 删除每日食谱
// @Produce  json
// @Param target body v1.DeleteCookBookBody true "删除每日食谱"
// @Success 200 {object} app.Response
// @Failure 500 {object} app.Response
// @Router /v1/delete [post]
// @Tags cookbook
func DeleteCookBook(c *gin.Context) {
	var (
		appG = app.Gin{C: c}
		body DeleteCookBookBody
	)

	httpCode, errCode, err := app.BindAndJsonCheck(c, &body)
	if errCode != e.SUCCESS {
		appG.Response(httpCode, errCode, err.Error())
		return
	}

	myService := cookbook_service.CommonParamsList{
		AccessToken: body.AccessToken,
		Uuid:        body.Uuid,
		Uid:         body.Uid,
	}

	exists, err := myService.ExistByUid()
	if err != nil {
		appG.Response(e.SUCCESS, e.ERROR_NOT_EXIST_SCHEDULE, nil)
		return
	}

	if !exists {
		appG.Response(http.StatusOK, e.ERROR_NOT_EXIST_SCHEDULE, nil)
		return
	}

	err = myService.Delete()
	if err != nil {
		fmt.Println(err)
		appG.Response(e.SUCCESS, e.ERROR_GET_SCHEDULE_FAIL, err)
		return
	}

	appG.Response(http.StatusOK, e.SUCCESS, nil)
}

type DetailCookBookBody struct {
	AccessToken string `json:"accessToken" binding:"required" example:"token"`
	Uuid        string `json:"uuid" binding:"required"` //创建人uuid
	Uid         string `json:"uid" binding:"required"`  //uid
}

// @Summary 每日食谱详情
// @Produce  json
// @Param target body v1.DetailCookBookBody true "每日食谱详情"
// @Success 200 {object} models.RespAppOne
// @Failure 500 {object} app.Response
// @Router /v1/detail [post]
// @Tags cookbook
func DetailCookBook(c *gin.Context) {
	var (
		appG = app.Gin{C: c}
		body DetailCookBookBody
	)

	httpCode, errCode, err := app.BindAndJsonCheck(c, &body)
	if errCode != e.SUCCESS {
		appG.Response(httpCode, errCode, err.Error())
		return
	}

	myService := cookbook_service.CommonParamsList{
		AccessToken: body.AccessToken,
		Uuid:        body.Uuid,
		Uid:         body.Uid,
	}

	exists, err := myService.ExistByUid()
	if err != nil {
		appG.Response(e.SUCCESS, e.ERROR_NOT_EXIST_SCHEDULE, nil)
		return
	}

	if !exists {
		appG.Response(http.StatusOK, e.ERROR_NOT_EXIST_SCHEDULE, nil)
		return
	}

	rs, err := myService.Detail()
	if err != nil {
		appG.Response(e.SUCCESS, e.ERROR_GET_SCHEDULE_FAIL, err)
		return
	}

	appG.Response(http.StatusOK, e.SUCCESS, rs)
}
