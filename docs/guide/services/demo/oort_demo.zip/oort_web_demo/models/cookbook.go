package models

import (
	"fmt"
	"time"

	"github.com/EDDYCJY/go-gin-example/pkg/util"

	"github.com/jinzhu/gorm"
)

func GetCookBookList(content string, uuid string, pageNum int, pageSize int, start_time int, end_time int, token string) ([]Oort_cookbook, int, error) {
	fmt.Println(content, uuid, pageNum, pageSize)
	var (
		ss    []Oort_cookbook
		err   error
		count int
	)

	Db := db.Debug().Table("oort_cookbook")
	if start_time != 0 && end_time != 0 {
		Db = Db.Where("created_on >= ? AND created_on <= ?", start_time, end_time)
	}
	if content != "" {
		Db = Db.Where("title LIKE ? OR content LIKE ? ", "%"+content+"%", "%"+content+"%")
	}
	err = Db.Count(&count).Offset((pageNum - 1) * pageSize).Limit(pageSize).Order("created_on desc").Find(&ss).Error
	if err != nil && err != gorm.ErrRecordNotFound {
		return ss, count, err
	}

	return ss, count, nil
}

// 判断uid是否存在
func ExistCookBookByUid(uid string) (bool, error) {
	var ss Oort_cookbook
	err := db.Select("id").Where("uid = ?", uid).First(&ss).Error
	if err != nil && err != gorm.ErrRecordNotFound {
		return false, err
	}
	if ss.ID > 0 {
		return true, nil
	}

	return false, nil
}

func AddCookBook(data map[string]interface{}, uuid string, token string) error {
	uid := util.GenUUID()
	day := time.Now().Format("2006-01-02")

	ss := Oort_cookbook{
		Uid:    uid,
		Uuid:   uuid,
		Title:  data["title"].(string),
		PicUrl: data["pic_url"].(string),
		Day:    day,
	}
	if err := db.Create(&ss).Error; err != nil {
		return err
	}

	return nil
}

func EditCookBook(body map[string]interface{}, uid string, uuid string, token string) error {
	if err := db.Debug().Model(&Oort_cookbook{}).Where("uid = ?", uid).Updates(body).Error; err != nil {
		return err
	}
	return nil
}

func DeleteCookBook(uid string, uuid string, token string) error {
	if err := db.Where("uid = ?", uid).Delete(&Oort_cookbook{}).Error; err != nil {
		return err
	}
	return nil
}

func DetailCookBook(uid string, uuid string, token string) (Oort_cookbook, error) {
	var ss Oort_cookbook

	if err := db.Where("uid = ?", uid).Find(&ss).Error; err != nil {
		return ss, err
	}

	return ss, nil
}
