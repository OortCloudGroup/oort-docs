package models

//Oort_work_schedule
type RespList struct {
	Code int      `json:"code" example:"200"` //返回码
	Msg  string   `json:"msg" example:"返回消息"`
	Data RespData `json:"data"`
}

type RespData struct {
	Count int             `json:"count"` //个数
	Lists []Oort_cookbook `json:"lists"`
}

type RespAppOne struct {
	Code int           `json:"code" example:"200"` //返回码
	Msg  string        `json:"msg" example:"返回消息"`
	Data Oort_cookbook `json:"data"`
}
