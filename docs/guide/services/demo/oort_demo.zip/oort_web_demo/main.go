package main

import (
	"fmt"
	"log"
	"net/http"
	"os"

	"github.com/EDDYCJY/go-gin-example/pkg/app"

	"github.com/gin-gonic/gin"

	"github.com/EDDYCJY/go-gin-example/models"
	"github.com/EDDYCJY/go-gin-example/pkg/gredis"
	"github.com/EDDYCJY/go-gin-example/pkg/logging"
	"github.com/EDDYCJY/go-gin-example/pkg/setting"
	"github.com/EDDYCJY/go-gin-example/pkg/util"
	"github.com/EDDYCJY/go-gin-example/routers"
)

func init() {
	setting.Setup(MyProgramVersion, MyProgramBuildData)
	models.Setup()
	logging.Setup()
	gredis.InitRedis()
	util.Setup()
	models.CreateTables()
	// 开启定时任务
	app.StartSchedule()
}

//版本号和编译时间
var MyProgramVersion = "v1.0.0.1"
var MyProgramBuildData = "20200608T1625"

// @title oort-web-demo API
// @version 1.0
// @description example of oortcloud-daily-cookbook api
// @BasePath /BaseUrl
// @license.name /MyProgramBuildData
func main() {
	gin.SetMode(setting.ServerSetting.RunMode)

	routersInit := routers.InitRouter()
	readTimeout := setting.ServerSetting.ReadTimeout
	writeTimeout := setting.ServerSetting.WriteTimeout
	endPoint := fmt.Sprintf(":%d", setting.ServerSetting.HttpPort)
	maxHeaderBytes := 1 << 20

	server := &http.Server{
		Addr:           endPoint,
		Handler:        routersInit,
		ReadTimeout:    readTimeout,
		WriteTimeout:   writeTimeout,
		MaxHeaderBytes: maxHeaderBytes,
	}

	log.Printf("|-----------------------------------|")
	log.Printf("|         oort-web-demo             |")
	log.Printf("|-----------------------------------|")
	log.Printf("|    version :   " + MyProgramVersion + "           |")
	log.Printf("|       data : " + MyProgramBuildData + "        |")
	log.Printf("|-----------------------------------|")
	log.Printf("|    Port" + endPoint + "     Pid:" + fmt.Sprintf("%d", os.Getpid()) + "        |")
	log.Printf("|-----------------------------------|")

	//log.Printf("[info] start http server listening %s", endPoint)

	server.ListenAndServe()

	// If you want Graceful Restart, you need a Unix system and download github.com/fvbock/endless
	//endless.DefaultReadTimeOut = readTimeout
	//endless.DefaultWriteTimeOut = writeTimeout
	//endless.DefaultMaxHeaderBytes = maxHeaderBytes
	//server := endless.NewServer(endPoint, routersInit)
	//server.BeforeBegin = func(add string) {
	//	log.Printf("Actual pid is %d", syscall.Getpid())
	//}
	//
	//err := server.ListenAndServe()
	//if err != nil {
	//	log.Printf("Server err: %v", err)
	//}
}
