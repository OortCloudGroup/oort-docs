package app

import (
	"fmt"
	"net/http"

	"github.com/EDDYCJY/go-gin-example/pkg/e"
	"github.com/astaxie/beego/validation"
	"github.com/gin-gonic/gin"
)

// BindAndValid binds and validates data
func BindAndValid(c *gin.Context, form interface{}) (int, int) {
	fmt.Println("BindAndValid")
	err := c.Bind(form)
	if err != nil {
		fmt.Println(err)
		return http.StatusBadRequest, e.INVALID_PARAMS
	}

	valid := validation.Validation{}
	check, err := valid.Valid(form)
	if err != nil {
		fmt.Println(err)
		fmt.Println(e.ERROR)
		return http.StatusInternalServerError, e.ERROR
	}
	if !check {
		MarkErrors(valid.Errors)
		return http.StatusBadRequest, e.INVALID_PARAMS
	}

	return http.StatusOK, e.SUCCESS
}

// BindAndValid binds and validates data
func BindAndJson(c *gin.Context, body interface{}) (int, int) {
	err := c.BindJSON(body)
	//err := c.ShouldBindJSON(body)
	if err != nil {
		fmt.Println("err :", err)
		fmt.Println(e.ERROR)
		return http.StatusBadRequest, e.INVALID_PARAMS
	}

	return http.StatusOK, e.SUCCESS
}

func BindAndJsonCheck(c *gin.Context, body interface{}) (int, int, error) {
	//err := c.BindJSON(body)//: 当结构体绑定参数失败时（即参数有误、传错时）,httpcode为400，无论开发者如何强制返回httpcode，code就是400 解决方法 : 绑定结构体的方法一概不适用【BindJSON】改为【ShouldBind】
	err := c.ShouldBindJSON(body)
	if err != nil {
		fmt.Println("err :", err)
		fmt.Println(e.ERROR)
		return http.StatusOK, e.INVALID_ERROR, err
	}

	return http.StatusOK, e.SUCCESS, nil
}
