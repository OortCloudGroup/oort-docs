package util

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/EDDYCJY/go-gin-example/pkg/setting"
	"github.com/google/uuid"
)

// Setup Initialize the util
func Setup() {
	jwtSecret = []byte(setting.AppSetting.JwtSecret)
	ExpireTime = setting.AppSetting.ExpireTime
}

//gen 36 uuid
func GenUUID() string {
	u, _ := uuid.NewRandom()
	return u.String()
}

//gen 32 uuid( no -)
func GenUUID32() string {
	u, _ := uuid.NewRandom()
	return strings.Replace(u.String(), "-", "", -1)
}

//求并集
func StrArrayUnion(slice1, slice2 []string) []string {
	m := make(map[string]int)
	for _, v := range slice1 {
		m[v]++
	}

	for _, v := range slice2 {
		times, _ := m[v]
		if times == 0 {
			slice1 = append(slice1, v)
		}
	}
	return slice1
}

//求交集
func StrArrayIntersect(slice1, slice2 []string) []string {
	m := make(map[string]int)
	nn := make([]string, 0)
	for _, v := range slice1 {
		m[v]++
	}

	for _, v := range slice2 {
		times, _ := m[v]
		if times == 1 {
			nn = append(nn, v)
		}
	}
	return nn
}

//https://blog.csdn.net/yiweiyi329/article/details/101030510
//求差集 slice1-并集
func StrArrayDifference(slice1, slice2 []string) []string {
	m := make(map[string]int)
	nn := make([]string, 0)
	inter := StrArrayIntersect(slice1, slice2)
	for _, v := range inter {
		m[v]++
	}

	for _, value := range slice1 {
		times, _ := m[value]
		if times == 0 {
			nn = append(nn, value)
		}
	}
	return nn
}

//CheckMobile 检查手机号码
func CheckMobile(mobile string) bool {
	isorno, _ := regexp.MatchString(`^(1[0-9][0-9]\d{4,8})$`, mobile)
	return isorno
}

//CheckIDCard 检查身份证
func CheckIDCard(id string) bool {
	id = strings.ToUpper(id)
	if len(id) != 15 && len(id) != 18 {
		return false
	}

	r := regexp.MustCompile("(\\d{15})|(\\d{17}([0-9]|X))")
	if !r.MatchString(id) {
		return false
	}

	if len(id) == 15 {
		_, err := time.Parse("01/02/2006", string([]byte(id)[8:10])+"/"+string([]byte(id)[10:12])+"/"+"19"+string([]byte(id)[6:8]))
		if err != nil {
			return false
		}
	} else {
		_, err := time.Parse("01/02/2006", string([]byte(id)[10:12])+"/"+string([]byte(id)[12:14])+"/"+string([]byte(id)[6:10]))
		if err != nil {
			return false
		}
		/*
			//检验18位身份证的校验码是否正确。
			//校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
			arrint := []int{7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2}
			arrch := []string{"1", "0", "X", "9", "8", "7", "6", "5", "4", "3", "2"}
			sign := 0
			for k, v := range arrint {
				inttemp, _ := strconv.Atoi(string([]byte(id)[k : k+1]))
				sign += inttemp * v
			}

			n := sign % 11
			valnum := arrch[n]
			if valnum != string([]byte(id)[17:18]) {
				return false
			}
		*/
	}
	return true
}

func byte2int(x byte) byte {
	if x == 88 {
		return 'X'
	}
	return (x - 48) // 'X' - 48 = 40;
}

func check_id(id [17]byte) int {
	arry := make([]int, 17)

	//强制类型转换，将[]byte转换成[]int ,变化过程
	// []byte -> byte -> string -> int
	//将通过range 将[]byte转换成单个byte,再用强制类型转换string()，将byte转换成string
	//再通过strconv.Atoi()将string 转换成int 类型
	for index, value := range id {
		arry[index], _ = strconv.Atoi(string(value))
	}

	var wi [17]int = [...]int{7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2}
	var res int
	for i := 0; i < 17; i++ {
		//fmt.Println("id =", i, byte2int(id[i]), wi[i])
		res += arry[i] * wi[i]
	}

	return (res % 11)
}

func verify_id(verify int, id_v byte) bool {
	var temp byte
	var i int
	a18 := [11]byte{1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2}

	for i = 0; i < 11; i++ {
		if i == verify {
			temp = a18[i]
			//fmt.Println("verify_id id",)
			// if a18[i] == 'X' ,let convert it to type string
			if a18[i] == 88 {
				fmt.Println("计算得到身份证最后一位是 ", string(a18[i]))
			} else {
				fmt.Println("计算得到身份证最后一位是 ", a18[i])
			}
			//fmt.Println(i, temp)
			break
		}
	}

	if temp == id_v {
		return true
	}
	return false
}

func IdCard_check(id_card_string string) bool {
	var id_card [18]byte // 'X' == byte(88)， 'X'在byte中表示为88
	var id_card_copy [17]byte

	fmt.Println("身份证号码是 = ", id_card_string)

	if len(id_card_string) < 18 {
		fmt.Println("必须要输入18位的身份证号码")
		return false
	}

	// 将字符串，转换成[]byte,并保存到id_card[]数组当中
	for k, v := range []byte(id_card_string) {
		id_card[k] = byte(v)
	}

	//复制id_card[18]前17位元素到id_card_copy[]数组当中
	for j := 0; j < 17; j++ {
		id_card_copy[j] = id_card[j]
	}

	return verify_id(check_id(id_card_copy), byte2int(id_card[17]))
}

func RemoveRepeatedElement(arr []string) (newArr []string) {
	newArr = make([]string, 0)
	for i := 0; i < len(arr); i++ {
		repeat := false
		for j := i + 1; j < len(arr); j++ {
			if arr[i] == arr[j] {
				repeat = true
				break
			}
		}
		if !repeat {
			newArr = append(newArr, arr[i])
		}
	}
	return
}

func VerifyEmailFormat(email string) bool {
	//pattern := `\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*` //匹配电子邮箱
	pattern := `^[0-9a-z][_.0-9a-z-]{0,31}@([0-9a-z][0-9a-z-]{0,30}[0-9a-z]\.){1,4}[a-z]{2,4}$`

	reg := regexp.MustCompile(pattern)
	return reg.MatchString(email)
}

// 各种字符串加星
func HideStar(str string) (result string) {
	if str == "" {
		return "***"
	}
	if strings.Contains(str, "@") {
		res := strings.Split(str, "@")
		if len(res[0]) < 3 {
			resString := "***"
			result = resString + "@" + res[1]
		} else {
			res2 := Substr2(str, 0, 3)
			resString := res2 + "***"
			result = resString + "@" + res[1]
		}
		return result
	} else {
		reg := `^1[0-9]\d{9}$`
		rgx := regexp.MustCompile(reg)
		mobileMatch := rgx.MatchString(str)
		if mobileMatch {
			result = Substr2(str, 0, 3) + "****" + Substr2(str, 7, 11)
		} else {
			nameRune := []rune(str)
			lens := len(nameRune)

			if lens <= 1 {
				result = "***"
			} else if lens == 2 {
				result = string(nameRune[:1]) + "*"
			} else if lens == 3 {
				result = string(nameRune[:1]) + "*" + string(nameRune[2:3])
			} else if lens == 4 {
				result = string(nameRune[:1]) + "**" + string(nameRune[lens-1:lens])
			} else if lens > 4 {
				//result = string(nameRune[:2]) + "***" + string(nameRune[lens-2:lens])
				result = string(nameRune[:4]) + "**********" + string(nameRune[lens-4:lens])
			}
		}
		return
	}
}

func Substr2(str string, start int, end int) string {
	rs := []rune(str)
	return string(rs[start:end])
}
