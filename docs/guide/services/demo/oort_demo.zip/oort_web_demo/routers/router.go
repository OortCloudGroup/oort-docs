package routers

import (
	//"log"
	"net/http"

	"github.com/gin-gonic/gin"

	_ "github.com/EDDYCJY/go-gin-example/docs"
	"github.com/swaggo/gin-swagger"
	"github.com/swaggo/gin-swagger/swaggerFiles"

	//"github.com/EDDYCJY/go-gin-example/middleware/jwt"
	"github.com/EDDYCJY/go-gin-example/pkg/app"
	"github.com/EDDYCJY/go-gin-example/pkg/e"
	"github.com/EDDYCJY/go-gin-example/pkg/export"
	"github.com/EDDYCJY/go-gin-example/pkg/qrcode"

	//"github.com/EDDYCJY/go-gin-example/pkg/setting"
	"github.com/EDDYCJY/go-gin-example/pkg/upload"
	"github.com/EDDYCJY/go-gin-example/routers/api"
	"github.com/EDDYCJY/go-gin-example/routers/api/v1"
)

// InitRouter initialize routing information
func InitRouter() *gin.Engine {
	r := gin.New()
	r.Use(gin.Logger())
	r.Use(gin.Recovery())

	//404
	r.NoRoute(func(c *gin.Context) {
		appG := app.Gin{C: c}
		appG.Response(http.StatusInternalServerError, e.INVALID_INTERFACE, nil)
	})

	r.StaticFS("/export", http.Dir(export.GetExcelFullPath()))
	r.StaticFS("/upload/images", http.Dir(upload.GetImageFullPath()))
	r.StaticFS("/qrcode", http.Dir(qrcode.GetQrCodeFullPath()))

	r.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))
	r.POST("/upload", api.UploadImage)

	//1、设计数据库
	//2、设计开发文档（接口设计）及错误码

	//通过配置文件来区分是走网关还是不走网关
	//HTTP_X_FORWARDED_HOST
	//HTTP_X_FORWARDED_PREFIX

	//获取统一用户的信息
	//r.GET("/unified/getuser", api.GetUnifiedInfo)
	/*
		r.GET("/auth", api.GetAuth)
		r.GET("/auth/getpublickey", api.GetPublicKey)

		r.POST("/auth/login", api.AuthLogin)
		authapi := r.Group("/auth/")
		authapi.Use(jwt.JWT())
		{
			//校验token
			authapi.GET("/check", api.CheckAuth)
		}
	*/
	//每日食谱
	mainapi := r.Group("/v1/")
	{
		//列表
		mainapi.POST("/list", v1.CookBookList)
		//新增
		mainapi.POST("/add", v1.AddCookBook)
		//编辑
		mainapi.POST("/edit", v1.EditCookBook)
		//删除
		mainapi.POST("/delete", v1.DeleteCookBook)
		//详情
		mainapi.POST("/detail", v1.DetailCookBook)
	}

	return r
}
