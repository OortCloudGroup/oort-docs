package util

import (
	"fmt"
)

// MyError is an error implementation that includes a time and message.
type MyError struct {
	//When time.Time
	Err string
}

func (e MyError) Error() string {
	return fmt.Sprintf("%v", e.Err)
}
