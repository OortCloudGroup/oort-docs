package app

import (
	"github.com/robfig/cron"
	"github.com/sirupsen/logrus"
)

func StartSchedule() {
	c := cron.New()
	addCronFunc(c, "@every 30s", RssTask)
	addCronFunc(c, "@every 1h", SitemapTask)
	c.Start()
}

func addCronFunc(c *cron.Cron, sepc string, cmd func()) {
	err := c.AddFunc(sepc, cmd)
	if err != nil {
		logrus.Error(err)
	}
}

func RssTask() {
	//定时任务
	//models.CronTask()
}

func SitemapTask() {
	//定时任务
}
