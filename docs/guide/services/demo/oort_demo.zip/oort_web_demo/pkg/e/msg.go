package e

var MsgFlags = map[int]string{
	SUCCESS:           "成功",
	ERROR:             "失败",
	INVALID_PARAMS:    "请求参数错误",
	INVALID_INTERFACE: "请求方法不存在",

	INVALID_ERROR:          "参数错误",
	INVALID_JSON:           "json格式错误",
	INVALID_THIRED_SERVICE: "调用第三方服务失败",
	SERVICE_INTERNAL_ERROR: "业务错误",
	INVALID_TOKEN:          "无效accessToken",
	MISS_PARAMS:            "缺少参数",

	//schedule
	ERROR_EXIST_SCHEDULE:       "已存在该食谱",
	ERROR_EXIST_SCHEDULE_FAIL:  "获取食谱失败",
	ERROR_NOT_EXIST_SCHEDULE:   "该食谱不存在",
	ERROR_GET_SCHEDULE_FAIL:    "获取食谱失败",
	ERROR_COUNT_SCHEDULE_FAIL:  "统计食谱失败",
	ERROR_ADD_SCHEDULE_FAIL:    "新增食谱失败",
	ERROR_EDIT_SCHEDULE_FAIL:   "修改食谱失败",
	ERROR_DELETE_SCHEDULE_FAIL: "删除食谱失败",
	ERROR_GET_HISTORY_FAIL:     "获取历史版本失败",
	//meet
	ERROR_EXIST_MEET:       "已存在该会议",
	ERROR_EXIST_MEET_FAIL:  "获取会议失败",
	ERROR_NOT_EXIST_MEET:   "该会议不存在",
	ERROR_GET_MEET_FAIL:    "获取会议失败",
	ERROR_COUNT_MEET_FAIL:  "统计会议失败",
	ERROR_ADD_MEET_FAIL:    "新增会议失败",
	ERROR_EDIT_MEET_FAIL:   "修改会议失败",
	ERROR_DELETE_MEET_FAIL: "删除会议失败",
	//task
	ERROR_EXIST_TASK:       "已存在该任务",
	ERROR_EXIST_TASK_FAIL:  "获取任务失败",
	ERROR_NOT_EXIST_TASK:   "该任务不存在",
	ERROR_GET_TASK_FAIL:    "获取任务失败",
	ERROR_COUNT_TASK_FAIL:  "统计任务失败",
	ERROR_ADD_TASK_FAIL:    "新增任务失败",
	ERROR_EDIT_TASK_FAIL:   "修改任务失败",
	ERROR_DELETE_TASK_FAIL: "删除任务失败",
	//memo
	ERROR_EXIST_MEMO:       "已存在该备注",
	ERROR_EXIST_MEMO_FAIL:  "获取备注失败",
	ERROR_NOT_EXIST_MEMO:   "该备注不存在",
	ERROR_GET_MEMO_FAIL:    "获取备注失败",
	ERROR_COUNT_MEMO_FAIL:  "统计备注失败",
	ERROR_ADD_MEMO_FAIL:    "新增备注失败",
	ERROR_EDIT_MEMO_FAIL:   "修改备注失败",
	ERROR_DELETE_MEMO_FAIL: "删除备注失败",
	//supplier classify
	ERROR_EXIST_CLASSIFY:       "已存在该分类",
	ERROR_EXIST_CLASSIFY_FAIL:  "获取分类失败",
	ERROR_NOT_EXIST_CLASSIFY:   "该分类不存在",
	ERROR_GET_CLASSIFY_FAIL:    "获取分类失败",
	ERROR_COUNT_CLASSIFY_FAIL:  "统计分类失败",
	ERROR_ADD_CLASSIFY_FAIL:    "新增分类失败",
	ERROR_EDIT_CLASSIFY_FAIL:   "修改分类失败",
	ERROR_DELETE_CLASSIFY_FAIL: "删除分类失败",
	//admin audit
	ERROR_EXIST_AUDIT:       "已存在该审核",
	ERROR_EXIST_AUDIT_FAIL:  "获取审核失败",
	ERROR_NOT_EXIST_AUDIT:   "该审核不存在",
	ERROR_GET_AUDIT_FAIL:    "获取审核失败",
	ERROR_COUNT_AUDIT_FAIL:  "统计审核失败",
	ERROR_ADD_AUDIT_FAIL:    "审核失败",
	ERROR_EDIT_AUDIT_FAIL:   "修改审核失败",
	ERROR_DELETE_AUDIT_FAIL: "删除审核失败",
	//admin supplier
	ERROR_EXIST_SUPPLIER:       "已存在该供应商",
	ERROR_EXIST_SUPPLIER_FAIL:  "获取供应商失败",
	ERROR_NOT_EXIST_SUPPLIER:   "该供应商不存在",
	ERROR_GET_SUPPLIER_FAIL:    "获取供应商失败",
	ERROR_COUNT_SUPPLIER_FAIL:  "统计供应商失败",
	ERROR_ADD_SUPPLIER_FAIL:    "新增供应商失败",
	ERROR_EDIT_SUPPLIER_FAIL:   "修改供应商失败",
	ERROR_DELETE_SUPPLIER_FAIL: "删除供应商失败",

	//log
	ERROR_GET_ADMINLOG_FAIL:   "获取日志失败",
	ERROR_COUNT_ADMINLOG_FAIL: "或者日志数量失败",

	ERROR_NOT_EXIST_REPLY:        "该评论不存在",
	ERROR_ADD_REPLY_FAIL:         "新增评论失败",
	ERROR_DELETE_REPLY_FAIL:      "删除评论失败",
	ERROR_CHECK_EXIST_REPLY_FAIL: "检查评论是否存在失败",
	ERROR_EDIT_REPLY_FAIL:        "修改评论失败",
	ERROR_COUNT_REPLY_FAIL:       "统计评论失败",
	ERROR_GET_REPLYS_FAIL:        "获取评论失败",
	ERROR_GET_REPLY_FAIL:         "获取单个评论失败",

	ERROR_AUTH_CHECK_TOKEN_FAIL:     "Token鉴权失败",
	ERROR_AUTH_CHECK_TOKEN_TIMEOUT:  "Token已超时",
	ERROR_AUTH_TOKEN:                "Token生成失败",
	ERROR_AUTH:                      "Token错误",
	ERROR_NOT_EXIST_USER:            "不存在该用户",
	ERROR_EXIST_USER_FAIL:           "获取用户信息失败",
	ERROR_USER_PASSWD:               "密码错误",
	ERROR_ENCRYPT:                   "加密失败",
	ERROR_DECODE:                    "解密失败",
	ERROR_UPLOAD_SAVE_IMAGE_FAIL:    "保存图片失败",
	ERROR_UPLOAD_CHECK_IMAGE_FAIL:   "检查图片失败",
	ERROR_UPLOAD_CHECK_IMAGE_FORMAT: "校验图片错误，图片格式或大小有问题",
}

// GetMsg get error information based on Code
func GetMsg(code int) string {
	msg, ok := MsgFlags[code]
	if ok {
		return msg
	}

	return MsgFlags[ERROR]
}
